# Reset_Demo - repeatability

Run this **before every demo**. Makes two things true again:

1. **The code is vulnerable again, in both repos.** Reverts `pom.xml`
   (and `VulnerableSearchRepository.java` for java-app-cve) on `main`
   back to each repo's own `vulnerable-baseline` git tag
   ([java-app-cve](https://github.com/kokunas/java-app-cve/releases/tag/vulnerable-baseline),
   [fraud-cve](https://github.com/kokunas/fraud-cve/releases/tag/vulnerable-baseline)),
   via direct commits through the GitHub Contents API (no PR - this is
   demo housekeeping, not a reviewed change). Each push automatically
   re-triggers that repo's own `build-and-push.yml`, republishing the
   vulnerable image to GHCR. Idempotent: if a file already matches the
   baseline, it's left alone (verified locally - reruns log `"already
   matches ... nothing to reset"` instead of creating no-op commits).
2. **Concert is empty.** Deletes every `application`, `source_repo`,
   `build_artifact`, `environment`, and `certificate` from the Concert
   instance via its own core API, so the next scan starts from nothing -
   matching the requirement that Concert has no demo data loaded before
   you start.

## Why not just re-baseline in git and leave Concert alone?

Because the demo's whole point is showing Concert **discover** the CVEs
from scratch (connect to GitHub, scan, see findings appear, prioritize).
If the `bankdemo` application/source_repo already exists with old scan
data, that first "watch it get discovered" beat doesn't land the same way
for a repeat audience.

## After running this, redeploy the running pods

Reset_Demo fixes the **source** and the **image** (new vulnerable image
lands in GHCR within ~1-2 minutes), but the **already-running** OpenShift
pods don't restart themselves. Before the next demo, roll both:

```
oc rollout restart deployment/bankdemo-app -n banco-kokunas
oc rollout restart deployment/fraud-cve-app -n banco-kokunas
```

## How to import

Concert Workflows console -> Workflows -> Import -> `Reset_Demo.zip`
(loose `.json` files show up greyed-out/unselectable in Concert's import
picker - it only accepts `.zip`, even for a single-flow bundle with no
subflows, matching how IBM distributes its own single-flow samples like
`trivy-github-scan.zip`).

## Trigger payload for this demo

`repos` is pre-filled with both repos' defaults except the two
`gh_api_token` fields (deliberately left blank - they're secrets). Paste
in the two tokens (`github_pat_java-app-cve`'s token and
`github_pat_fraud-cve`'s token) plus `concert_api_key` on each run:

```json
{
  "repos": "[{\"gh_repo_url\": \"https://github.com/kokunas/java-app-cve\", \"gh_api_token\": \"<token 1>\", \"baseline_ref\": \"vulnerable-baseline\", \"target_branch\": \"main\", \"reset_files\": [\"pom.xml\", \"src/main/java/com/kokunas/bankdemo/repository/VulnerableSearchRepository.java\"]}, {\"gh_repo_url\": \"https://github.com/kokunas/fraud-cve\", \"gh_api_token\": \"<token 2>\", \"baseline_ref\": \"vulnerable-baseline\", \"target_branch\": \"main\", \"reset_files\": [\"pom.xml\"]}]",
  "concert_url": "https://concert-concert.apps.itz-4j78fp.pok-lb.techzone.ibm.com",
  "concert_api_key": "<Concert API key>",
  "concert_instance_id": "0000-0000-0000-0000"
}
```

## Verified locally

Ran this exact logic twice against the real repo and the real Concert
instance during development:
- **Idempotent run**: both files already matched baseline -> logged
  `already_reset`, no commits created; Concert had 1 application + 1
  source_repo -> both deleted successfully.
- **Real revert run**: pushed a simulated merged fix (log4j bumped to
  2.24.3) directly to `main`, then ran Reset_Demo again -> it correctly
  detected the drift and reverted `pom.xml` via a real authenticated PUT
  to the GitHub Contents API (commit `1cc3ca2`), while leaving the
  already-correct SQLi file untouched.
